All data here is from [Cognitive Computation Group](https://cogcomp.org/page/resource_view/98).
